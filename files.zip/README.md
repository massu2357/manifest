# DGX Spark 2ノード vLLM — docker compose 移行手順

NVIDIA公式プレイブック（`run_cluster.sh` + Ray）で動作確認済みの構成を、
docker compose による常駐運用へ移行するための資材と手順である。

---

## 1. 前提条件

移行前に以下がすべて満たされていること。

| 項目 | 確認方法 |
|---|---|
| QSFPのIPが手動設定（netplan）になっている | `ip addr show enp1s0f1np1` |
| 両ノード間の疎通がとれる | `ping -c3 <相手IP>` |
| パスワードレスSSHが通る | `ssh <相手IP> hostname` |
| `run_cluster.sh` で分散推論が成功している | `curl http://localhost:8000/v1/models` |
| モデルが両ノードにダウンロード済み | `du -sh ~/.cache/huggingface/hub/models--*` |

最後の項目が重要である。`~/.cache/huggingface` は各ノードのローカルディスクを
マウントしているだけで共有されていないため、head 側にしか無い状態では worker が
重みを読めずに起動に失敗する。

---

## 2. ファイル構成

```
~/spark-vllm/
├── docker-compose.yml     # 両ノード共通
├── entrypoint.sh          # 両ノード共通（ロールで分岐）
├── env.head.example       # → head で .env にコピー
└── env.worker.example     # → worker で .env にコピー
```

compose 定義とスクリプトは両ノードで同一である。差分は `.env` に閉じ込めている。

---

## 3. 事前に採取しておく値

`.env` を埋めるために、両ノードで以下を実行して控えておく。

```bash
# 1) イメージ名（run_cluster.sh で使っていたもの）
echo $VLLM_IMAGE
docker images | grep vllm

# 2) QSFP のインターフェース名と対応する HCA 名
ibdev2netdev
#   例) rocep1s0f1 port 1 ==> enp1s0f1np1 (Up)
#       → NCCL_SOCKET_IFNAME=enp1s0f1np1 / NCCL_IB_HCA=rocep1s0f1

# 3) 自ノードの QSFP 側 IP
ip addr show enp1s0f1np1

# 4) HFキャッシュの実パス
ls -d ~/.cache/huggingface

# 5) RDMA デバイスの有無
ls /dev/infiniband
```

`ibdev2netdev` の出力で `(Up)` になっている側を選ぶこと。
各物理ポートには論理インターフェースが2つ存在し（`enp1s0f1np1` と
`enP2p1s0f1np1`）、片方は同じ物理ポートの別名である。ここを取り違えると
NCCL が通信経路を見つけられない。

`/dev/infiniband` が存在しない場合は、`docker-compose.yml` の `devices:` を
2行ともコメントアウトする。

---

## 4. 配置

両ノードで実行する。

```bash
mkdir -p ~/spark-vllm && cd ~/spark-vllm
# 4ファイルを配置したあと
chmod +x entrypoint.sh
```

head 側:

```bash
cp env.head.example .env
vi .env        # 第3節で採取した値に書き換える
```

worker 側:

```bash
cp env.worker.example .env
vi .env
```

---

## 5. 起動

**先に `run_cluster.sh` 由来のコンテナを停止しておくこと。**
ポート6379とGPUメモリが競合する。

```bash
# 両ノードで
docker ps
docker stop <name> && docker rm <name>
```

起動は両ノードで実行する。順序は問わない
（head が worker の参加を待つ設計にしてあるため）。

```bash
docker compose up -d
docker compose logs -f
```

head のログに以下が順に現れれば正常である。

```
[entrypoint] starting ray head on 192.168.100.10:6379
[entrypoint] waiting for 2 ray nodes to join...
[entrypoint]   alive nodes: 1/2 (0s)
[entrypoint]   alive nodes: 2/2 (10s)
[entrypoint] ray cluster ready. launching vllm serve...
...
INFO:     Application startup complete.
```

---

## 6. 動作確認

head ノードで実行する。プロキシ環境では `--noproxy '*'` が必須である。
これを付けないと、ローカルへのリクエストがプロキシに転送されて失敗する。

```bash
curl --noproxy '*' http://localhost:8000/v1/models

curl --noproxy '*' http://localhost:8000/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "Qwen/Qwen3-8B",
    "messages": [{"role":"user","content":"Write a haiku about GPUs."}],
    "max_tokens": 64
  }'
```

Ray クラスタの状態確認:

```bash
docker exec vllm-node ray status
```

---

## 7. 運用コマンド

```bash
docker compose logs -f          # ログ追従
docker compose restart          # 再起動
docker compose down             # 停止・削除
docker compose ps               # 状態（healthy / unhealthy）
```

モデルを差し替える場合は `.env` の `MODEL` を書き換えて、
**両ノードで** `docker compose up -d` を実行する
（compose が環境変数の変更を検知してコンテナを再作成する）。

---

## 8. run_cluster.sh との対応

| `run_cluster.sh` の引数 | `.env` の変数 |
|---|---|
| 第2引数（head の IP） | `HEAD_ADDR` |
| 第3引数（`--head` / `--worker`） | `NODE_ROLE` |
| 第4引数（HFキャッシュのパス） | `HF_CACHE` |
| `-e VLLM_HOST_IP=` | `VLLM_HOST_IP` |
| `-e NCCL_*` | 同名の変数 |
| `docker exec ... vllm serve <model>` | `MODEL` ほか |

---

## 9. トラブルシュート

### head が `alive nodes: 1/2` のまま進まない

worker が Ray に参加できていない。worker 側のログを確認する。

```bash
# worker で
docker compose logs --tail 50
ping -c3 192.168.100.10
```

`HEAD_ADDR` の値と、head 側の実IPが一致しているかを確認する。

### `ncclCommInitRank` でエラー

RoCEv2 の GID インデックス不一致が典型的な原因である。
worker 側の `.env` の `NCCL_IB_GID_INDEX` を `4` などに変えて再試行する。
原因切り分けのため、一時的に `NCCL_DEBUG=INFO` にするとよい。

### `docker compose ps` が unhealthy のまま

`restart: unless-stopped` はプロセス終了時にのみ再起動するため、
unhealthy でも自動復旧はしない。ログを見て原因を特定すること。
なお、モデルのロード中は unhealthy 判定されないよう
`start_period: 20m` を設定してある。405B で足りない場合は延長する。

### OS再起動後に起動ループする

QSFPのIPが消えている可能性がある。netplan 設定が永続化されているか確認する。

```bash
sudo netplan get
ip addr show enp1s0f1np1
```

---

## 10. 次の段階（任意）

- **systemd 化**: ネットワーク設定 → compose 起動の依存順序を明示したい場合
- **unhealthy 時の自動復旧**: autoheal コンテナ、または systemd タイマー
- **Kubernetes + LeaderWorkerSet**: 3ノード以上、または基盤として展開する場合

2台の固定構成であれば、本手順（compose + netplan による永続IP）で
運用要件は満たせる。
