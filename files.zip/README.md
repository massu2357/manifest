# DGX Spark 2ノード vLLM — docker compose 移行手順

NVIDIA公式プレイブック（`run_cluster.sh` + Ray）で動作確認済みの構成を、
docker compose による常駐運用へ移行するための資材と手順である。

---

## 0. 公式手順との差分

| 項目 | 公式プレイブック | 本資材 |
|---|---|---|
| Ray の導入 | `run_cluster.sh` を sed でパッチし、起動のたびに `pip install` | イメージに焼き込み（`Dockerfile`） |
| プロセスの常駐 | ターミナルを開いたまま維持 | `restart: unless-stopped` |
| サーバ起動 | `docker exec` で別途実行 | entrypoint に統合 |
| 分散通信の環境変数 | `-e` で7個指定 | `.env` の `MN_IF_NAME` 1つから展開 |
| RDMA | 指定なし（TCP経路） | 同左（任意で有効化可能） |

分散通信の設定値は公式と完全に同一である。変えたのは「どう起動するか」だけである。

---

## 1. 前提条件

| 項目 | 確認方法 |
|---|---|
| QSFPのIPが手動設定（netplan）になっている | `ip addr show enp1s0f1np1` |
| 両ノード間の疎通がとれる | `ping -c3 <相手IP>` |
| `run_cluster.sh` で分散推論が成功している | `curl http://localhost:8000/v1/models` |
| モデルが**両ノードに**ダウンロード済み | `du -sh ~/.cache/huggingface/hub/models--*` |

`~/.cache/huggingface` は各ノードのローカルディスクであり共有されない。
head 側にしか無い状態では worker が重みを読めずに起動に失敗する。

---

## 2. ファイル構成

```
~/spark-vllm/
├── Dockerfile             # Ray入りイメージのビルド定義
├── ca/                    # 社内CA置き場（不要なら空のまま）
├── docker-compose.yml     # 両ノード共通
├── entrypoint.sh          # 両ノード共通（ロールで分岐）
├── env.head.example       # → head で .env にコピー
└── env.worker.example     # → worker で .env にコピー
```

---

## 3. 事前に採取する値

両ノードで実行して控えておく。

```bash
# QSFP のインターフェース名（公式の検証例は enp1s0f1np1）
ip -br addr

# 自ノードの QSFP 側 IP
export MN_IF_NAME=enp1s0f1np1
ip -4 addr show $MN_IF_NAME | grep -oP '(?<=inet\s)\d+(\.\d+){3}'

# HFキャッシュの実パスと使用量
du -sh ~/.cache/huggingface
```

---

## 4. イメージのビルド

**両ノードで実行**する。または片方でビルドし、`docker save` / `docker load` で
もう一方へ持ち込む（エアギャップ環境ではこちら）。

```bash
mkdir -p ~/spark-vllm/ca && cd ~/spark-vllm
# 4ファイル + Dockerfile を配置したあと

# 社内CAがある場合のみ
# cp /usr/local/share/ca-certificates/<社内CA>.crt ca/

docker build \
  --build-arg HTTP_PROXY="$HTTP_PROXY" \
  --build-arg HTTPS_PROXY="$HTTPS_PROXY" \
  -t vllm-ray:26.05 .
```

ビルド末尾で `ray --version` が表示されれば成功である。

もう一方へ持ち込む場合:

```bash
docker save vllm-ray:26.05 | gzip > vllm-ray.tar.gz
# 転送後
gunzip -c vllm-ray.tar.gz | docker load
```

---

## 5. 配置

```bash
cd ~/spark-vllm
chmod +x entrypoint.sh

cp env.head.example .env      # worker 側は env.worker.example
vi .env                       # 第3節で採取した値に書き換える
```

書き換えるのは実質 `VLLM_HOST_IP` / `HEAD_ADDR` / `MN_IF_NAME` / `HF_CACHE` の4つである。

---

## 6. 起動

**先に `run_cluster.sh` 由来のコンテナを停止しておくこと。**
ポート6379とGPUメモリが競合する。

```bash
docker ps
docker stop <name> && docker rm <name>
```

起動は両ノードで実行する。順序は問わない
（head が worker の参加を待つ設計にしてある）。

```bash
docker compose up -d
docker compose logs -f
```

head のログに以下が順に現れれば正常である。

```
[entrypoint] ray: ray, version 2.x.x
[entrypoint] role=head self=192.168.100.10 head=192.168.100.10
[entrypoint] starting ray head on 192.168.100.10:6379
[entrypoint] waiting for 2 ray nodes to join...
[entrypoint]   alive nodes: 1/2 (0s)
[entrypoint]   alive nodes: 2/2 (10s)
[entrypoint] ray cluster ready. launching vllm serve...
...
INFO:     Application startup complete.
```

`ray not found in image; installing from PyPI...` が出た場合は、
`.env` の `VLLM_IMAGE` が素の NGC イメージのままである。第4節のビルドを確認すること。

---

## 7. 動作確認

head ノードで実行する。プロキシ環境では `--noproxy '*'` が必須である。

```bash
curl --noproxy '*' http://localhost:8000/v1/models

curl --noproxy '*' http://localhost:8000/v1/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "Qwen/Qwen3-8B",
    "prompt": "Write a haiku about a GPU",
    "max_tokens": 32,
    "temperature": 0.7
  }'
```

クラスタ状態:

```bash
docker exec vllm-node ray status
```

Ray ダッシュボード（head の 8265 番）はホストネットワーク上にあるため、
ワークステーションからは SSH トンネルで参照する。

```bash
ssh -L 8265:localhost:8265 nvidia@192.168.100.10
```

---

## 8. オフライン化

モデルのダウンロードが済んだら、両ノードの `.env` を変更する。

```bash
HF_HUB_OFFLINE=1
TRANSFORMERS_OFFLINE=1
```

これにより、ローカルにモデルがあっても HuggingFace へ更新確認に行く動作が止まる。
`VLLM_NO_USAGE_STATS=1` と `DO_NOT_TRACK=1` は既定で有効にしてある。

検証は、`.env` のプロキシを空にして起動し、正常に
`Application startup complete.` まで到達するかで行う。

`pull_policy: never` を指定してあるため、イメージを誤って外部から取得しにいくこともない。

---

## 9. 運用コマンド

```bash
docker compose logs -f          # ログ追従
docker compose ps               # 状態（healthy / unhealthy）
docker compose restart          # 再起動
docker compose down             # 停止・削除
```

モデルを差し替える場合は `.env` の `MODEL` を書き換え、**両ノードで**
`docker compose up -d` を実行する（環境変数の変更を検知して再作成される）。

---

## 10. RDMA (RoCE) の有効化（任意）

公式プレイブックは RDMA デバイスを指定していないため、現状の構成は
NCCL が TCP ソケットを使う経路で動作している。RDMA を使うと、
TP=2 で層ごとに発生する小さな集約通信のレイテンシが下がる。

有効化する前に、まず現状を確認する。

```bash
ls /dev/infiniband
ibdev2netdev
docker compose logs | grep -E "NET/(IB|Socket)"
```

`/dev/infiniband` が存在する場合のみ、`docker-compose.yml` 末尾の
コメントアウト部分（`cap_add` / `ulimits` / `devices`）を有効化する。
存在しない環境で有効化すると、デバイスが見つからず起動に失敗する。

`NCCL_IB_GID_INDEX` は指定しないこと。現行の NCCL は既定値 `-1` で
RoCEv2 対応の GID を自動選択する。`ncclCommInitRank` エラーが出た
場合にのみ、手動指定を検討する。

有効化後、ログが `NET/IB : Using [0]rocep1s0f1:1/RoCE` に変わっていれば成功である。

---

## 11. トラブルシュート

### `ray: command not found`

イメージに Ray が入っていない。第4節の `Dockerfile` でビルドしたイメージを
`.env` の `VLLM_IMAGE` に指定しているか確認する。

### head が `alive nodes: 1/2` のまま進まない

worker が Ray に参加できていない。worker 側のログと疎通を確認する。

```bash
docker compose logs --tail 50
ping -c3 192.168.100.10
```

`HEAD_ADDR` の値と head 側の実IPが一致しているかを確認する。

### 起動時にハングして進まない

`GLOO_SOCKET_IFNAME` / `TP_SOCKET_IFNAME` が未設定だと、PyTorch 分散の
初期化が別のインターフェースを掴んでハングする。`.env` の `MN_IF_NAME` が
正しいか確認する。

### `docker compose ps` が unhealthy のまま

`restart: unless-stopped` はプロセス終了時にのみ再起動するため、
unhealthy でも自動復旧はしない。ログを見て原因を特定すること。
モデルのロード中に誤判定されないよう `start_period: 20m` を設定してある。
405B で足りない場合は延長する。

### OS再起動後に起動ループする

QSFPのIPが消えている可能性がある。netplan 設定の永続化を確認する。

```bash
sudo netplan get
ip addr show enp1s0f1np1
```

---

## 12. 次の段階（任意）

- **systemd 化**: ネットワーク設定 → compose 起動の依存順序を明示したい場合
- **unhealthy 時の自動復旧**: autoheal コンテナ、または systemd タイマー
- **Kubernetes + LeaderWorkerSet**: 3ノード以上、または基盤として展開する場合

2台の固定構成であれば、本手順（compose + netplan による永続IP + Ray入りイメージ）で
運用要件は満たせる。
